-- Database: "TeamManager"
-- DROP DATABASE "TeamManager";

CREATE DATABASE "TeamManager"
  WITH OWNER = postgres
       ENCODING = 'UTF8'
       TABLESPACE = pg_default
       LC_COLLATE = 'C'
       LC_CTYPE = 'C'
       CONNECTION LIMIT = -1;

       -- Table: public.feuille
       -- DROP TABLE public.feuille;
       CREATE TABLE public.feuille
       (
         "ID" integer NOT NULL DEFAULT nextval('"Feuille_ID_seq"'::regclass),
         intitule text NOT NULL, -- Intitule de la feuille.
         dateMatch date NOT NULL, -- Date du Match.
         CONSTRAINT "Feuille_pkey" PRIMARY KEY ("ID")
       )
       WITH (
         OIDS=TRUE
       );
       ALTER TABLE public.feuille
         OWNER TO postgres;
       COMMENT ON COLUMN public.feuille.intitule IS 'Intitule de la feuille.';
       COMMENT ON COLUMN public.feuille.dateMatch IS 'Date du match.';

       -- Table: public.joueur
       -- DROP TABLE public.joueur;
       CREATE TABLE public.joueur
       (
         "ID" integer NOT NULL DEFAULT nextval('"Joueur_ID_seq"'::regclass),
         nom text NOT NULL, -- Nom du joueur.
         prenom text NOT NULL, -- Prenom du joueur.
         poste text NOT NULL, -- Poste du joueur.
         CONSTRAINT "Joueur_pkey" PRIMARY KEY ("ID")
       )
       WITH (
         OIDS=TRUE
       );
       ALTER TABLE public.joueur
         OWNER TO postgres;
       COMMENT ON COLUMN public.joueur.nom IS 'Nom du joueur.';
       COMMENT ON COLUMN public.joueur.prenom IS 'Prenom du joueur.';
       COMMENT ON COLUMN public.joueur.poste IS 'Poste du joueur.';

       -- Table: public.coach
       -- DROP TABLE public.coach;
       CREATE TABLE public.coach
       (
         id integer NOT NULL DEFAULT nextval('"Coach_ID_seq"'::regclass),
         nom text NOT NULL, -- Nom du coach.
         prenom text NOT NULL, -- Prénom du coach.
         mail text NOT NULL, -- Mail du coach.
         CONSTRAINT "Coach_pkey" PRIMARY KEY (id)
       )
       WITH (
         OIDS=TRUE
       );
       ALTER TABLE public.coach
         OWNER TO postgres;
       COMMENT ON COLUMN public.coach.nom IS 'Nom du coach.';
       COMMENT ON COLUMN public.coach.prenom IS 'Prénom du coach.';
       COMMENT ON COLUMN public.coach.mail IS 'Mail du coach.';
