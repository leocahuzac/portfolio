/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package teammanager;

import teammanager.modele.Requetes;

/**
 *
 * @author L_CAH
 */
public class TeamManager {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CoachView cv = new CoachView();
        cv.setVisible(true);
    }
    
}
