/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package teammanager.modele;

import Entite.Coach;
import Entite.Feuille;
import Entite.Joueur;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author l_cah
 */

// Classe spécifique aux requetes avec la base
public class Requetes {

    Connection conn = null;

    public Requetes() {

    }

    // Connection a la bdd
    public Connection DBconnect() {

    try {
      Class.forName("com.mysql.jdbc.Driver");
      System.out.println("Driver MySQL : OK.");

      String url = "jdbc:mysql://localhost:3306/TeamManager";
      String user = "root";
      String passwd = "root";

      conn = DriverManager.getConnection(url, user, passwd);
      System.out.println("Connexion effective !");

    } catch (Exception e) {
      e.printStackTrace();
    }
    return conn;
  }

    // Ajout d'un Joueur en base
    public Joueur AddJoueur(String Nom, String Prenom, String Poste){

        // Instancier classe Joueur
        Joueur vh = new Joueur(Nom, Prenom, Poste);
        try {
            DBconnect();
            Statement state = null;
            state = this.conn.createStatement();
            String query = vh.addJoueur();
            state.executeUpdate(query);
        } catch(SQLException e) {
            e.printStackTrace();
        } finally {
            if ( conn != null )
                try {
                    // Fermeture de la connexion
                    conn.close();
                } catch ( SQLException ignore ) {

                }
                return null;
            }
        }

    // Ajout d'un Coach en base
    public Coach AddCoach(String nom, String prenom, String mail){

        //Instancier classe Coach
        Coach cl = new Coach(nom, prenom, mail);
        try {
            DBconnect();
            Statement state = null;
            state = conn.createStatement();
            String query = cl.addCoach();
            state.executeUpdate(query);
        } catch(SQLException e) {
            e.printStackTrace();
        } finally {
            if ( conn != null )
                try {
                    // Fermeture de la connexion
                    conn.close();
                } catch ( SQLException ignore ) {

                }
                return null;
            }
        }

    // Ajout d'une Feuille en base
    public Feuille AddFeuille(String intitule, String date){

        //Instancier classe Feuille
        Feuille pc = new Feuille(intitule, date);
        try {
            DBconnect();
            Statement state = null;
            state = conn.createStatement();
            String query = pc.addFeuille();
            state.executeUpdate(query);
        } catch(SQLException e) {
            e.printStackTrace();
        }
        finally {
            if ( conn != null )
                try {
                    // Fermeture de la connexion
                    conn.close();
                } catch ( SQLException ignore ) {

                }
                return null;
            }
        }

    // Méthode qui permet l'affichage de la table Coach
 public ResultSet AffCoach() {
     
    ResultSet rslt; // On stock la requete ici
    try
    {
        Coach clt = new Coach();
        DBconnect();
        Statement stm = conn.createStatement();
        // On exécute la requete SQL
        rslt = stm.executeQuery(clt.affCoach());
    }catch(SQLException e)   
    {
       System.out.println(e.getMessage());
       return null;
    }
    finally {
            if ( conn != null )
                try {
                    // Fermeture de la connexion
                    conn.close();
                } catch ( SQLException ignore ) {

                }
    }
    return rslt;
 }
 
 // Méthode qui permet l'affichage de la table Feuille
 public ResultSet AffFeuille() {
     
    ResultSet rslt; // On stock la requete ici
    try
    {
        Feuille pc = new Feuille();
        DBconnect();
        Statement stm = conn.createStatement();
        // On exécute la requete SQL
        rslt = stm.executeQuery(pc.affFeuille());
    }catch(SQLException e)   
    {
       System.out.println(e.getMessage());
       return null;
    }
    finally {
            if ( conn != null )
                try {
                    // Fermeture de la connexion
                    conn.close();
                } catch ( SQLException ignore ) {

                }
    }
    return rslt;
 }
 
 // Méthode qui permet l'affichage de la table Joueur
 public ResultSet AffJoueur() {
     
    ResultSet rslt; // On stock la requete ici
    try
    {
        Joueur pc = new Joueur();
        DBconnect();
        Statement stm = conn.createStatement();
        // On exécute la requete SQL
        rslt = stm.executeQuery(pc.affJoueur());
    }catch(SQLException e)   
    {
       System.out.println(e.getMessage());
       return null;
    }
    finally {
            if ( conn != null )
                try {
                    // Fermeture de la connexion
                    conn.close();
                } catch ( SQLException ignore ) {

                }
    }
    return rslt;
 }
}
