/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entite;

/**
 *
 * @author L_CAH
 */
public class Coach {
    
    String nom = null;
    String prenom = null;
    String mail = null;
   
    public Coach() {
        
    }
    
    public Coach(String nom, String prenom, String tel) {
        
        this.nom = nom;
        this.prenom = prenom;
        this.mail = mail;
    }
    
    public String addCoach() {
        
        String rqt = "INSERT INTO coach(nom, prenom, mail) VALUES ('"+this.nom+"', '"+this.prenom+"', '"+this.mail+"')";
        return rqt;
    }
    
    public String affCoach() {
        
        String rqt = "SELECT * FROM public.coach";
        return rqt;
    }
}
