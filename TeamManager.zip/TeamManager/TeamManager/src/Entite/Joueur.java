/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entite;

/**
 *
 * @author L_CAH
 */
public class Joueur {
    
    String nom = null;
    String prenom = null;
    String poste = null;
    
    public Joueur(String nom, String prenom, String poste) {
        
        this.nom = nom;
        this.prenom = prenom;
        this.poste = poste;
    }
    
    public Joueur() {
        
    }
    
    public String addJoueur(){
        
        String rqt = "INSERT INTO joueur(nom, prenom, poste) VALUES ('"+this.nom+"', '"+this.prenom+"', '"+this.poste+"')";
        return rqt;
    }
    
     public String affJoueur() {
        
        String rqt = "SELECT * FROM public.joueur";
        return rqt;
    }
}
